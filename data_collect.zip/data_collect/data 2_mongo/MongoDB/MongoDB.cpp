#include <bits/stdc++.h>
#include <HTTPClient.h>
#include <WiFi.h>
#include "MongoDB.h"

MongoDB::MongoDB(String device, String sender, int version, int delay, String description = "")
{
    this->device = device;
    this->sender = sender;
    this->version = version;
    this->delay = delay;
    this->description = description;
    this->dataPoints = {};
    this->iteration = 0;
}

int MongoDB::dumpToServer()
{
    Serial.println("Dumping");

    HTTPClient http;

    http.begin("http://d682-2401-4900-367e-92e0-8c48-9b80-e03-8e9b.ngrok.io/");
    http.addHeader("Content-Type", "application/json");
    Serial.println("device " + String(this->device));
//    Serial.println(this->sender);
//    Serial.println(this->version);
//    Serial.println(this->delay);
//    Serial.println(this->description);
//    Serial.println(this->iteration);
//    Serial.println(this->zeroValue);
//    Serial.println(this->dataPoints);
    
    String JSONstr = String("{")                                               //
                     + "\"device\": " + "\"" + this->device + "\", "           //
                     + "\"sender\": " + "\"" + this->sender + "\", "           //
                     + "\"version\": " + this->version + ", "                  //
                     + "\"delay\": " + this->delay + ", "                      //
                     + "\"description\": " + "\"" + this->description + "\", " //
                     + "\"iteration\": " + this->iteration + ", "              //
                     + "\"zeroValue\": " + this->zeroValue + ", "              //
                     + "\"data\": [";

    reverse(this->dataPoints.begin(), this->dataPoints.end());
    while (this->dataPoints.size())
    {
        JSONstr += String(this->dataPoints.back());

        this->dataPoints.pop_back();
        if (this->dataPoints.size())
            JSONstr += ",";
    }

    JSONstr += "] }";

//    Serial.println(JSONstr);
    
    int statusCode = http.POST(JSONstr);

    if (statusCode == HTTP_CODE_OK)
        Serial.println("Success");
    else if (statusCode == HTTP_CODE_CONFLICT)
    {
        Serial.println("Datapoints with the same quadruple (device, sender, version, iteration) exists. Can't overwrite.");
        return 1;
    }
    else
        Serial.println(http.errorToString(statusCode).c_str());

    this->iteration++;

    return 0;
}

void MongoDB::setZeroValue(int value)
{
    this->zeroValue = value;
}

int MongoDB::pushData(int data)
{
    
    this->dataPoints.push_back(data);
//    Serial.println(this->dataPoints.size());
    if (this->dataPoints.size() == 1000)
        return this->dumpToServer();

    return 0;
}

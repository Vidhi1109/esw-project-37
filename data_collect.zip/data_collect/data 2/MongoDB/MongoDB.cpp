#include <bits/stdc++.h>
#include <HTTPClient.h>
#include <WiFi.h>
#include "MongoDB.h"
#include "encrypt.h"

using namespace std;

void createCI(String& val)
{
//     val = "[1,2,3,4,5000000]";
//   String data="[" + String(69) + ", " + String("engineer") + " , " + String(34)+"]";
  std::string key = "VidhiMafia";
  HTTPClient http;
  http.begin("https://esw-onem2m.iiit.ac.in/~/in-cse/in-name/Team-37/Node-1/Data");
  http.addHeader("X-M2M-Origin", "0msPeJ:NGB!1i");
  http.addHeader("Content-Type", "application/json;ty=4");
  http.addHeader("Content-Length" , "30000");

//   int code = http.POST("{\"m2m:cin\": {\"cnf\":\"application/json\",\"con\": " + val + "\"cnf\": \"text\"""}}");
char* a = (char*)malloc(sizeof(char) * val.length());

Serial.println("Val is " + val);

val.toCharArray(a , val.length());
std::string s = a;
string req_data_2 = encrypt(s , key);

String vidhi = "";
for(int i=0; i<req_data_2.length(); i++)
{
  vidhi += req_data_2[i];
}

Serial.println("vidhi is " + vidhi);

String req_data = String() + "{\"m2m:cin\": {"

  + "\"con\": \"" + vidhi + "\","

  + "\"cnf\": \"text\""

  + "}}";

  // char* jbk = (char*)malloc(sizeof(char)*req_data.length());
  // String hugsy = String(jbk);
  // String anurag = String() + hugsy; 

  Serial.println("Data value is " + req_data);
  int code = http.POST(req_data);

  Serial.println(code);
  if (code == -1) {
    Serial.println("UNABLE TO CONNECT TO THE SERVER");
  }
  http.end();
}
MongoDB::MongoDB(String device, String sender, int version, int delay, String description = "")
{
    this->device = device;
    this->sender = sender;
    this->version = version;
    this->delay = delay;
    this->description = description;
    this->dataPoints = {};
    this->iteration = 0;
}

int MongoDB::dumpToServer()
{
    
    String JSONstr = String("[");                                               
    reverse(this->dataPoints.begin(), this->dataPoints.end());
    while (this->dataPoints.size())
    {
        JSONstr += String(this->dataPoints.back());

        this->dataPoints.pop_back();
        if (this->dataPoints.size())
            JSONstr += ", ";
    }

    JSONstr += "]";
    createCI(JSONstr);
}

void MongoDB::setZeroValue(int value)
{
    this->zeroValue = value;
}

int MongoDB::pushData(int data)
{
    
    this->dataPoints.push_back(data);
//    Serial.println(this->dataPoints.size());
    if (this->dataPoints.size() == 1000)
        return this->dumpToServer();

    return 0;
}

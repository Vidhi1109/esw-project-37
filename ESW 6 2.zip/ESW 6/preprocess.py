from lib2to3.pytree import Node
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from tensorflow import keras
import numpy as np
import pycountry_convert as pc
import os 
from sklearn.preprocessing import LabelEncoder
from os import listdir
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from os.path import isfile, join
import csv
plt.style.use('ggplot')
plt.rcParams['font.family'] = 'sans-serif' 
plt.rcParams['font.serif'] = 'Ubuntu' 
plt.rcParams['font.monospace'] = 'Ubuntu Mono' 
plt.rcParams['font.size'] = 14 
plt.rcParams['axes.labelsize'] = 12 
plt.rcParams['axes.labelweight'] = 'bold' 
plt.rcParams['axes.titlesize'] = 12 
plt.rcParams['xtick.labelsize'] = 12 
plt.rcParams['ytick.labelsize'] = 12 
plt.rcParams['legend.fontsize'] = 12 
plt.rcParams['figure.titlesize'] = 12 
plt.rcParams['image.cmap'] = 'jet' 
plt.rcParams['image.interpolation'] = 'none' 
plt.rcParams['figure.figsize'] = (12, 10) 
plt.rcParams['axes.grid']=True
plt.rcParams['lines.linewidth'] = 2 
plt.rcParams['lines.markersize'] = 8
colors = ['xkcd:pale orange', 'xkcd:sea blue', 'xkcd:pale red', 'xkcd:sage green', 'xkcd:terra cotta', 'xkcd:dull purple', 'xkcd:teal', 'xkcd: goldenrod', 'xkcd:cadet blue',
'xkcd:scarlet']

# 0 -> NoDevice
# 1 -> Soak

NoDevice = []
Soak = []
Spin = []
Rinse = []
Wash = []

f1 = open( 'NoDevice.txt' , 'r')
f2 = open( 'Soak.txt' , 'r')
f3 = open('Spin.txt', 'r')
f4 = open('Rinse.txt' , 'r')
f5 = open('Wash.txt' , 'r')

# Store the comma separated values in the file into a list
for line in f1:
    NoDevice = line.split(',')

for line in f2:
    Soak = (line.split(','))

for line in f3:
    Spin = (line.split(','))

for line in f4:
    Rinse = (line.split(','))

for line in f5:
    Wash = (line.split(','))

print(len(NoDevice) , len(Soak) , len(Spin) , len(Rinse) , len(Wash))


# # Store only the absolute value of the list 
# NoDevice = [abs(float(i)) for i in NoDevice]
# Soak = [abs(float(i)) for i in Soak]
# Spin = [abs(float(i)) for i in Spin]
# Rinse = [abs(float(i)) for i in Rinse]


# Add timestamp to NoDevice data and soak data 
for i in range(0 , len(NoDevice)):
    NoDevice[i] = [10*i , NoDevice[i] , 0]

for i in range(0 , len(Soak)):
    Soak[i] = [10*i , Soak[i] , 1]

for i in range(0 , len(Spin)):
    Spin[i] = [10*i , Spin[i] , 2]

for i in range(0 , len(Rinse)):
    Rinse[i] = [10*i , Rinse[i] , 3]

for i in range(0 , len(Wash)):
    Wash[i] = [10*i , Wash[i] , 4]

print(NoDevice[0:5])
print(Soak[0:5])
print(Spin[0:5])
print(Rinse[0:5])
print(Wash[0:5])

# Print data in data file 
dataFile = open('data.csv' , 'w')
writer = csv.writer(dataFile)
writer.writerow(["Time" , "Current" , "Mode_ID"])
for data in NoDevice:
    writer.writerow(data)
for data in Soak:
    writer.writerow(data)
for data in Spin:
    writer.writerow(data)
for data in Rinse:
    writer.writerow(data)
for data in Wash:
    writer.writerow(data)
dataFile.close()
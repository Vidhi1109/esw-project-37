from lib2to3.pytree import Node
import matplotlib.pyplot as plt

NoDevice = []
Soak = []

f1 = open('Spin.txt', 'r')
# f2 = open('Soak.txt', 'r')

# Store the comma separated values in the file into a list
for line in f1:
    NoDevice = line.split(',')

# for line in f2:
#     Soak = (line.split(','))

# Store only the absolute value of the list 
NoDevice = [(float(i)) for i in NoDevice]
# Soak = [abs(float(i)) for i in Soak]

print(len(NoDevice))
# print(len(Soak))

# Plot points in NoDevice and Soak on same graph
# plt.plot(NoDevice, label='NoDevice')
# plt.show()
# plt.plot(Soak, label='Soak')
# plt.show()

# Label in graph
plt.plot(NoDevice[5000:10000], 'g*', label='NoDevice')
# plt.plot(NoDevice[5000:10000],'ro')
plt.show()
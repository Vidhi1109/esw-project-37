# Importing libraries and modules


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from tensorflow import keras
import numpy as np
import pycountry_convert as pc
import os
from sklearn.preprocessing import LabelEncoder
from os import listdir
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from os.path import isfile, join


plt.style.use('ggplot') 
plt.rcParams['font.family'] = 'sans-serif' 
plt.rcParams['font.serif'] = 'Ubuntu' 
plt.rcParams['font.monospace'] = 'Ubuntu Mono' 
plt.rcParams['font.size'] = 14 
plt.rcParams['axes.labelsize'] = 12 
plt.rcParams['axes.labelweight'] = 'bold' 
plt.rcParams['axes.titlesize'] = 12 
plt.rcParams['xtick.labelsize'] = 12 
plt.rcParams['ytick.labelsize'] = 12 
plt.rcParams['legend.fontsize'] = 12 
plt.rcParams['figure.titlesize'] = 12 
plt.rcParams['image.cmap'] = 'jet' 
plt.rcParams['image.interpolation'] = 'none' 
plt.rcParams['figure.figsize'] = (12, 10) 
plt.rcParams['axes.grid']=True
plt.rcParams['lines.linewidth'] = 2 
plt.rcParams['lines.markersize'] = 8
colors = ['xkcd:pale orange', 'xkcd:sea blue', 'xkcd:pale red', 'xkcd:sage green', 'xkcd:terra cotta', 'xkcd:dull purple', 'xkcd:teal', 'xkcd: goldenrod', 'xkcd:cadet blue',
'xkcd:scarlet']


# Data pre process
min_number = 50000
numModes = 5
data = pd.read_csv('data.csv')


numEntry = [len(data[data['Mode_ID'] == i]) for i in range(numModes)]

# find minimum value in numentry
min_number = min(numEntry)

# convert min_number to its nearest multiple of 1000
min_number = min_number - min_number%1000
print(min_number)


# Store the min_number values of all class type in red_data 
red_data = data[data['Mode_ID'] == 0]
red_data = red_data[len(red_data)-min_number::]

for i in range(1 , numModes):
    data_i = data[data['Mode_ID'] == i]
    data_i = data_i[len(data_i) - min_number::]
    red_data = pd.concat([red_data, data_i])


red_data_label = red_data.reset_index().drop('index', axis = 1)
tot = int(len(red_data_label)/min_number)

labels = []
for i in range(0,tot):
    labels.append(red_data_label.loc[i*min_number:(i+1)*min_number].Mode_ID.to_list()[0])

labels = np.array(labels)
le = LabelEncoder()
le = le.fit(labels)
labels = np.array(le.transform(labels))
red_data = red_data.reset_index().drop(columns='index')
len_data = len(red_data)

x = np.array(red_data.Current)                        ## Check this , should we use red_train_data or red_data
y = np.array(red_data.Mode_ID)

x_train = x
y_train = y 

x_train = x_train.reshape(-1 , 1000)
y_train = y_train.reshape(-1 , 1000)

temp = []

for i in range(0 , len(y_train)):
    temp.append(y_train[i][0])

y_train = np.array(temp)

temp = []
for i in range(0 , len(x_train)):
    temp.append([x_train[i] , y_train[i]])
# temp = (temp.append[x_train[i] , y_train[i]] for i in range(0 , len(x_train)))

temp = np.array(temp)

# shuffle an np array
np.random.shuffle(temp)

# 80% train data from temp
x_train = temp[0:int(0.8*len(temp)) , 0]
y_train = temp[0:int(0.8*len(temp)) , 1]

# 20% test data from temp
x_test = temp[int(0.8*len(temp)):len(temp) , 0]
y_test = temp[int(0.8*len(temp)):len(temp) , 1]

# Convert list in x_tarin to columns 
x_train = np.array([x_train[i] for i in range(0 , len(x_train))])
x_test = np.array([x_test[i] for i in range(0 , len(x_test))])

print("This is what i want " , x_train.shape)
print(x_test.shape)


classes = np.unique(np.concatenate((y_train, y_test), axis=0))

# print(x_train.shape)
print(x_test.shape , type(x_test))

x_train = x_train.reshape((x_train.shape[0], x_train.shape[1], 1))
x_test = x_test.reshape((x_test.shape[0], x_test.shape[1]  , 1))

num_classes = len(np.unique(y_train))
print(num_classes)


# # Optional code : Can be changed later 
idx = np.random.permutation(len(x_train))
x_train = x_train[idx]
y_train = y_train[idx]

x_test = np.asarray(x_test).astype('float32')
y_test = np.asarray(y_test).astype('float32')
x_train = np.asarray(x_train).astype('float32')
y_train = np.asarray(y_train).astype('float32')

print("Size of train data is " , x_train.shape)
print("Size of test data is " , x_test.shape)

#######################################
######################################
#### Machine Learning Model ##########

def make_model(input_shape):
    input_layer = keras.layers.Input(input_shape)

    conv1 = keras.layers.Conv1D(filters=64, kernel_size=3, padding="same")(input_layer)
    conv1 = keras.layers.BatchNormalization()(conv1)
    conv1 = keras.layers.ReLU()(conv1)

    conv2 = keras.layers.Conv1D(filters=64, kernel_size=3, padding="same")(conv1)
    conv2 = keras.layers.BatchNormalization()(conv2)
    conv2 = keras.layers.ReLU()(conv2)

    conv3 = keras.layers.Conv1D(filters=64, kernel_size=3, padding="same")(conv2)
    conv3 = keras.layers.BatchNormalization()(conv3)
    conv3 = keras.layers.ReLU()(conv3)

    gap = keras.layers.GlobalAveragePooling1D()(conv3)

    output_layer = keras.layers.Dense(num_classes, activation="softmax")(gap)

    return keras.models.Model(inputs=input_layer, outputs=output_layer)


model = make_model(input_shape=x_train.shape[1:])
keras.utils.plot_model(model, show_shapes=True)

model.summary()

# #############################################
# #############################################
# #############################################

epochs = 500
batch_size = 32

callbacks = [
    keras.callbacks.ModelCheckpoint(
        "best_model.h5", save_best_only=True, monitor="val_loss"
    ),
    keras.callbacks.ReduceLROnPlateau(
        monitor="val_loss", factor=0.5, patience=20, min_lr=0.0001
    ),
    keras.callbacks.EarlyStopping(monitor="val_loss", patience=50, verbose=1),
]
model.compile(
    optimizer="adam",
    loss="sparse_categorical_crossentropy",
    metrics=["sparse_categorical_accuracy"],
)
history = model.fit(
    x_train,
    y_train,
    batch_size=batch_size,
    epochs=epochs,
    callbacks=callbacks,
    validation_split=0.2,
    verbose=1,
)

model = keras.models.load_model("best_model.h5")

test_loss, test_acc = model.evaluate(x_test, y_test)

print("Test accuracy", test_acc)
print("Test loss", test_loss)

ans = model.predict(x_test, verbose=1)
ans = np.argmax(ans , axis = 1)


print("hurray " , ans)
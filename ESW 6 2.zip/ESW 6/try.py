import csv
import matplotlib.pyplot as plt
import random
import numpy as np
plot1 = []
plot2 = []
plot3 = []


data = []

def shuffle_data(data):
    random.shuffle(data)
    data = np.array(data)
    return data

rows = []

with open('feeds.csv','r') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        if(row[2] != ''):
            data.append((row[2]))
        if (row[3] != ''):
            data.append((row[3]))
        if (row[4] != ''):
            data.append((row[4]))


data = data[4:]
# print(data)

# print index of the element with value x in data 
for i in range(len(data)):
    if data[i] == 'field1':
        data[i] = 0
    if data[i] == 'field2':
        data[i] = 0
    if data[i] == 'field3':
        data[i] = 0
    if data[i] == 'field4':
        data[i] = 0


# convert string to float 
data = [float(i) for i in data]

index = 0
for val in data:
    # print(index)
    if val > 2:
        data[index] = 0.1
    else:
        data[index] = val
    index += 1


# print(len(data))
# print(len(plot1))

# shuffle data in data in batch of 100
x = shuffle_data(data)
y = shuffle_data(data)
z = shuffle_data(data)

x.reshape(1 , -1)
y.reshape(1 , -1)
z.reshape(1 , -1)

op = open('feeds.csv' , 'r')
dt = csv.DictReader(op)

index = 1
for row in dt:
        rows.append({'created_at':row['created_at'] , 
        'field1' : x[index] ,
        'field3' : y[index] ,
        'field4' : z[index] ,
        'field8' : row['field4'],
        'elevation' : row['elevation']})

        index += 1

op.close()

op = open("feeds.csv" , 'w')
fieldnames = ['created_at' , 'field1' , 'field3' , 'field4' , 'field8' , 'elevation']
writer = csv.DictWriter(op , fieldnames = fieldnames)
writer.writeheader()
writer.writerows(rows)
op.close()

